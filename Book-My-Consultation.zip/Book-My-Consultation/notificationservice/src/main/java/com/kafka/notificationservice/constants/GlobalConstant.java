package com.kafka.notificationservice.constants;

public interface GlobalConstant {
    String PENDING_STATUS = "Pending";
    String ACTIVE_STATUS = "Active";
    String REJECT_STATUS = "Rejected";
}
