package com.doctor.book.consultant.doctor.server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoctorServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
