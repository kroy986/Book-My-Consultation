package com.doctor.book.consultant.payment.service.constants;

public interface RolesConstant {
    String ROLE_DOCTOR = "ROLE_DOCTOR";
    String ROLE_USER = "ROLE_USER";
    String ROLE_ADMIN = "ROLE_ADMIN";
}
