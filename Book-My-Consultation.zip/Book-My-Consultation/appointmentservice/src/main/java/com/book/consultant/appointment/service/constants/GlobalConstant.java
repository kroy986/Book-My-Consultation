package com.book.consultant.appointment.service.constants;

public interface GlobalConstant {
    String PENDING_STATUS = "Pending";
    String CONFIRMED_STATUS = "Confirmed";
    String PENDING_PAYMENT = "PendingPayment";
}
