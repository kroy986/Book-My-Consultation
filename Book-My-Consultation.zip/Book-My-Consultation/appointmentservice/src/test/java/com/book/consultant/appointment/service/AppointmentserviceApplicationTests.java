package com.book.consultant.appointment.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppointmentserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
